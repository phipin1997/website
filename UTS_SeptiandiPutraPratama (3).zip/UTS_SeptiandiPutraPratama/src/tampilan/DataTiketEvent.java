/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tampilan;
import java.sql.*;
import java.io.File;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.table. DefaultTableModel;
import koneksi.koneksi;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author Who_Im_I
 */
public class DataTiketEvent extends javax.swing.JFrame {
private Connection conn = new koneksi().connect();
private DefaultTableModel tabmode;
    /**
     * Creates new form FromPasien
     */
    public DataTiketEvent() {
        initComponents();
        datatable();
    }
    protected void aktif(){
    kodtik.setEnabled(true);
    kattik.setEnabled(true);
    tgl.setEnabled(true);
    lok.setEnabled(true);
    namven.setEnabled(true);
    harga.setEnabled(true);
    stok.setEnabled(true);
    kodtik.requestFocus();
}

    protected void kosong() {
    kodtik.setText("");
    kattik.setSelectedIndex(0);
    tgl.setText("");
    lok.setText("");
    namven.setText("");
    harga.setText("");
    stok.setValue(0);
}

   protected void datatable() {
    Object[] Baris = {"Kode Tiket", "Nama Event", "Kategori Tiket", "Harga", "Tanggal Event", "Lokasi", "Stock"};
    tabmode = new DefaultTableModel(null, Baris);
    tabeldatatiket.setModel(tabmode);
    String sql = "SELECT * FROM tiket_event";
    try {
        java.sql.Statement stat = conn.createStatement();
        ResultSet hasil = stat.executeQuery(sql);
        while (hasil.next()) {
            String a = hasil.getString("kode_tiket");
            String b = hasil.getString("nama_event");
            String c = hasil.getString("kategori_tiket");
            String d = hasil.getString("harga");
            String e = hasil.getString("tanggal_event");
            String f = hasil.getString("lokasi");
            String g = hasil.getString("stock");
            String[] data = {a, b, c, d, e, f, g};
            tabmode.addRow(data);
        }
    } catch (Exception e) {
        e.printStackTrace(); // agar error terlihat saat runtime
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenu1 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        kodtik = new javax.swing.JTextField();
        namven = new javax.swing.JTextField();
        harga = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabeldatatiket = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        tgl = new javax.swing.JTextField();
        lok = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        stok = new javax.swing.JSpinner();
        kattik = new javax.swing.JComboBox<>();
        print = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();

        jTextField5.setText("jTextField5");

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("NPM   : 202243500375");

        jLabel2.setText("Kode Tiket");

        jLabel3.setText("Nama Event");

        jLabel4.setText("Kategori Tiket");

        jLabel5.setText("Harga");

        jLabel6.setText("Tanggal Event");

        harga.setText("Rp. ");
        harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hargaActionPerformed(evt);
            }
        });

        jButton2.setText("SAVE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("EDIT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("DELETE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        tabeldatatiket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Tiket", "Nama Event", "Kategori Tiket", "Harga", "Tanggal Event", "Lokasi", "Stock"
            }
        ));
        tabeldatatiket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabeldatatiketMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabeldatatiket);

        jLabel8.setText("Lokasi ");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 255));
        jLabel9.setText("NAMA : Septiandi Putra Pratama");

        jLabel10.setText("Stock");

        kattik.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "VIP", "Reguler", "Standar" }));

        print.setText("PRINT");
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 554, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(117, 117, 117)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(kodtik, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                                    .addComponent(namven)
                                    .addComponent(harga)
                                    .addComponent(tgl)
                                    .addComponent(lok)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(stok)
                                        .addGap(34, 34, 34))
                                    .addComponent(kattik, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 227, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel1)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(print)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(kodtik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(namven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(kattik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(harga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton3)
                    .addComponent(jButton2)
                    .addComponent(print))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );

        jMenu2.setText("File");

        jMenu4.setText("jMenu4");
        jMenu2.add(jMenu4);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Edit");
        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    String sql = "INSERT INTO tiket_event (kode_tiket, nama_event, kategori_tiket, harga, tanggal_event, lokasi, stock) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try {
        PreparedStatement stat = conn.prepareStatement(sql);
        stat.setString(1, kodtik.getText());
        stat.setString(2, namven.getText());
        stat.setString(3, kattik.getSelectedItem().toString());
        stat.setString(4, harga.getText());
        stat.setString(5, tgl.getText());
        stat.setString(6, lok.getText());
        stat.setString(7, stok.getValue().toString());
        
        stat.executeUpdate();
        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        kosong();
        kodtik.requestFocus();
        datatable();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Data Gagal Disimpan " + e.getMessage());
    }

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tabeldatatiketMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabeldatatiketMouseClicked
    int bar = tabeldatatiket.getSelectedRow(); 
    String a = tabmode.getValueAt(bar, 0).toString(); 
    String b = tabmode.getValueAt(bar, 1).toString(); 
    String c = tabmode.getValueAt(bar, 2).toString(); 
    String d = tabmode.getValueAt(bar, 3).toString(); 
    String e = tabmode.getValueAt(bar, 4).toString(); 
    String f = tabmode.getValueAt(bar, 5).toString();
    String g = tabmode.getValueAt(bar, 6).toString();

    kodtik.setText(a);
    namven.setText(b);
    kattik.setSelectedItem(c);
    harga.setText(d);
    tgl.setText(e);
    lok.setText(f);

    try {
        int nilaiStock = Integer.parseInt(g);
        stok.setValue(nilaiStock);
    } catch (NumberFormatException ex) {
        stok.setValue(0); // fallback ke 0 jika parsing gagal
        JOptionPane.showMessageDialog(this, "Data stock tidak valid: " + g, "Kesalahan", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_tabeldatatiketMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    String sql = "UPDATE tiket_event SET nama_event = ?, kategori_tiket = ?, harga = ?, tanggal_event = ?, lokasi = ?, stock = ? WHERE kode_tiket = ?";
    try {
    PreparedStatement stat = conn.prepareStatement(sql);
    stat.setString(1, namven.getText());
    stat.setString(2, kattik.getSelectedItem().toString());
    stat.setString(3, harga.getText());
    stat.setString(4, tgl.getText());
    stat.setString(5, lok.getText());
    stat.setInt(6, (int) stok.getValue());
    stat.setString(7, kodtik.getText());

    stat.executeUpdate();
    JOptionPane.showMessageDialog(null, "Data Berhasil Diupdate");
    kosong();
    kodtik.requestFocus();
    datatable();
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Data Gagal Diupdate: " + e.getMessage());
}

        // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    int ok = JOptionPane.showConfirmDialog(null,"hapus","Konfirmasi Dialog", JOptionPane.YES_NO_CANCEL_OPTION); 
    if (ok==0){
    String sql = "DELETE FROM tiket_event WHERE kode_tiket = '"+kodtik.getText()+"'";
    try {
        PreparedStatement stat = conn.prepareStatement(sql);
        stat.executeUpdate();
        JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
        kosong();
        kodtik.requestFocus();
        datatable();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Data Gagal Dihapus " + e.getMessage());
    }
    }// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hargaActionPerformed

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
      try {
    // Lokasi file .jasper (file hasil compile dari .jrxml)
    String namaFile = "src/tampilan/report1.jasper";
    Connection con = new koneksi().connect();
    // Parameter untuk report, bisa dikosongkan jika tidak ada parameter
    HashMap<String, Object> parameter = new HashMap<>();
    // File report
    File report_file = new File(namaFile);
    // Load report (gunakan variabel report_file agar konsisten)
    JasperReport report = (JasperReport) JRLoader.loadObject(report_file);
    // Isi report dengan data dari database
    JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameter, con);
    // Tampilkan report
    JasperViewer.viewReport(jasperPrint, false);
    JasperViewer.setDefaultLookAndFeelDecorated(true);
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error menampilkan laporan: " + e.getMessage());
}

    }//GEN-LAST:event_printActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        org.apache.log4j.BasicConfigurator.configure();
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DataTiketEvent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DataTiketEvent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DataTiketEvent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DataTiketEvent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DataTiketEvent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField harga;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JComboBox<String> kattik;
    private javax.swing.JTextField kodtik;
    private javax.swing.JTextField lok;
    private javax.swing.JTextField namven;
    private javax.swing.JButton print;
    private javax.swing.JSpinner stok;
    private javax.swing.JTable tabeldatatiket;
    private javax.swing.JTextField tgl;
    // End of variables declaration//GEN-END:variables
}
